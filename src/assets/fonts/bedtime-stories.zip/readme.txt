This font is 100% free and can be used WITHOUT the permission of Lars Manenschijn
If you use this font for commercial use it would be great if you can send me a pdf.