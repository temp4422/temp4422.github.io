

                          [ StimulEye Fonts ]


        This font may be used free of charge for non-commercial
        projects.  Please contact me if you plan to use it for
        other purposes.

        It may be distributed free of charge on any websites
        provided this file is intact.

        Comments, suggestions, and questions are always welcome,
        as are donations =)

        Website:  http://www.stimuleyefonts.com

        Contact:  stimuleyefonts@hotmail.com

        Thanks, and enjoy!
        Aileen Lau